/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assembler;

/**
 *
 * @author hp
 */
public class Node {
    String address;
    int value;
    String name; 
    Node next;
}
class LinkedList
{
    static Node head;
    static int address=0;
    String hex(int n)
    {
        String s=Integer.toHexString(n);
        if(s.length()==3)
        {
            s=0+s;
        }
        else if(s.length()==2)
        {
            s=0+s;
            s=0+s;
        }
        else if(s.length()==1)
        {
            s=0+s;
            s=0+s;
            s=0+s;
        }
        return s;
    }
    void insert(int value,String name)
    {
        Node n=new Node();
        n.value=value;
        n.address=hex(LinkedList.address++);
        n.name=name;
        if(head==null)
        {
            head=n;
            n.next=null;
        }
        else
        {
            Node n1=head;
            while(n1.next!=null)
            {
                n1=n1.next;
            }
            n1.next=n;
            n.next=null;
        }
    }
   /*static void shows()
    {
        Node n=head;
        while(n!=null)
        {
            System.out.println(n.value+","+n.address+","+n.name);
            n=n.next;
        }
    }
   /* public static void main(String[] args) {
        LinkedList n=new LinkedList();
        n.insert(2,"a");
        LinkedList n1=new LinkedList();
        n1.insert(3,"b");
        LinkedList n2=new LinkedList();
        n2.insert(4,"c");
        LinkedList n3=new LinkedList();
        n3.insert(17,"d");
        LinkedList n4=new LinkedList();
        n4.shows();
    }*/
}
